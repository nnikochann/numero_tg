#!/bin/bash

echo "Останавливаем контейнеры..."
docker-compose down

echo "Контейнеры остановлены."